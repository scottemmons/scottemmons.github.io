$(function() {
	$("#tree").treeview({
		collapsed: true,
		animated: "medium",
		control: "#tree-control",
		persist: "location"
	});
})