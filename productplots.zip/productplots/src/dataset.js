var dataset = [{"label":"beer","categoryNum":1,"gender":0.62,"age":27,"income":45000,"kids":0},
{"label":"wine","categoryNum":1,"gender":0.41,"age":45,"income":70000,"kids":1.6},
{"label":"truck","categoryNum":2,"gender":0.56,"age":34,"income":55000,"kids":2.1},
{"label":"lipstick","categoryNum":2,"gender":0.12,"age":39,"income":47000,"kids":1.4},
{"label":"magazine","categoryNum":-1,"gender":0.33,"age":32,"income":60000,"kids":0.3}];